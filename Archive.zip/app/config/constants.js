module.exports = {
    db_pass: 'ABC123456',
    db_user: 'enigcreator',
    stripe_test_secret: 'sk_test_bK7ovpzVa2JEYm2rS8Gc9B9E',
    stripe_test_publishable: 'pk_test_EaCLt2P7qnTsEyjZIcPw9yCb',
    test_gmail: 'email.amp.bot@gmail.com',
    test_gmail_pass: 'amp123!@#',
    test_gmail_name: 'No Reply - AMP',
    dentist_pay_link: '/dentist/auth/pay/',
    patient_activation_link: '/api/patient/auth/activate/',
    stripe_default_currency: 'usd'
}