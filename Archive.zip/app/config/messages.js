module.exports = {
    wrong_login: 'Wrong email or password'
}