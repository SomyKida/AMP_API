import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-theme-setup',
  templateUrl: './theme-setup.component.html',
  styleUrls: ['./theme-setup.component.scss']
})
export class ThemeSetupComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
